#!/bin/bash
[ ! -d ~/class ] && mkdir class
cd ~/class
#export UR="jedi02"
openssl genrsa -out ${UR}.key 2048
openssl req -new -key ~/class/${UR}.key -out ~/class/${UR}.csr -subj "/CN=${UR}/O=jedi"
export BASE64_CSR=$(cat ${UR}.csr | base64 | tr -d '\n')
cat csr.yaml | envsubst | kubectl apply -f -
kubectl certificate approve ${UR}-csr
kubectl get csr ${UR}-csr -o jsonpath='{.status.certificate}' | base64 -d > /home/bigred/class/${UR}.crt
sudo kubectl config set-credentials ${UR} --client-certificate=/home/bigred/class/${UR}.crt --client-key=/home/bigred/class/${UR}.key
kubectl config view | grep -A 10 "name: $UR"
