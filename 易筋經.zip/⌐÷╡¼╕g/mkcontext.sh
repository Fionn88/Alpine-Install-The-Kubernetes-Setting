#!/bin/bash
# 建立學生namespace
kubectl create namespace ${UR}
# 建立學生專屬入口
sudo kubectl config set-context ${UR}-context --cluster=default --namespace=${UR} --user=${UR}
# 檢查
kubectl config view | grep -B 4 ${UR}-context
# 建立role&rolebinding
cat role.yaml | envsubst | kubectl apply -f -
cat rolebind.yaml | envsubst | kubectl apply -f -
