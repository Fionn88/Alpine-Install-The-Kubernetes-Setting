#!/bin/bash
source con
scnt=$(ps aux|grep -v grep|grep "busybox httpd -p $gw_port"|tr -s " " |cut -d ' ' -f2)
kill -9 $scnt && echo "stop httpd ok!!" 
