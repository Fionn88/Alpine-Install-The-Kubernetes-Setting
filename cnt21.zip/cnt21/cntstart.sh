#!/bin/bash
source config
cat /etc/os-release | grep 'NAME="Ubuntu"' &>/dev/null
[ "$?" != "0" ] && echo "the system is not Ubuntu" && exit 1
[ `hostname` != "$HN" ] && echo "wrong hostname" && exit 1
[ `whoami` != "$UR" ] && echo "wrong user" && exit 1
[ `pwd` != ~/cnt2 ] && echo "Please move to ~/cnt2" && exit 1
echo "`hostname` update ok"
sudo apt update &> /dev/null

which sshpass &> /dev/null
[ "$?" != "0" ] && echo "install sshpass" && sudo apt-get install sshpass &>/dev/null
which ./busybox &> /dev/null
[ "$?" != "0" ] && echo "install busybox" && wget https://busybox.net/downloads/binaries/1.28.1-defconfig-multiarch/busybox-x86_64 >/dev/null && chmod +x busybox-x86_64 && mv busybox-x86_64 busybox

ps aux|grep -v grep | grep "busybox httpd -p $HTTPORT" &>/dev/null
if [ $? != 0 ];then
  ./busybox httpd -p $HTTPORT -h ~/cnt2/www &>/dev/null
#else
#  echo "httpd port $HTTPORT already exist Please Check" && exit 1
fi
for n in $CLUSTER
do
  nc -w 1 -z $n 22 &>/dev/null
  if [ "$?" == "0" ];then
    sshpass -p 'root' ssh  root@$n "apk add curl" &>/dev/null
    sshpass -p 'root' ssh  root@$n "curl $IP:$HTTPORT/set/prefly.sh | sh" &>/dev/null
    echo "$n system prefly check ok"
  else
    echo "$n not exist"
  fi
done 
