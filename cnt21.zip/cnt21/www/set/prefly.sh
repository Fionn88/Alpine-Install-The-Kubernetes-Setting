#!/bin/bash
apk update &> /dev/null
apk upgrade &> /dev/null
[ $? = 0 ] && echo "system upgrade ok"
which nano &>/dev/null
if [ "$?" != "0" ];then
  apk add nano bash curl tree sudo grep procps &> /dev/null
  [ $? = 0 ] && echo "apk add ok"
  echo '%wheel ALL=(ALL) NOPASSWD:ALL' >> /etc/sudoers
  [ $? = 0 ] && echo "sudo Nopasswd OK"
  echo 'StrictHostKeyChecking no' >> /etc/ssh/ssh_config
  [ $? = 0 ] && echo "No HostKeyChecking OK"
  /etc/init.d/sshd restart
else
 echo "system ready"
fi

if [ ! -d  /home/bigred ];then
  adduser -s /bin/bash -h /home/bigred -D bigred
  addgroup bigred wheel
  echo -e "bigred\nbigred\n" | passwd bigred &> /dev/null
  echo "bigred ready"
else
echo "bigred exist"
fi
