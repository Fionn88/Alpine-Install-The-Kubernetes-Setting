#!/bin/bash
source config
[ `hostname` != "$HN" ] && echo "wrong hostname" && exit 1
[ `whoami` != "$UR" ] && echo "wrong user" && exit 1
[ `pwd` != ~/cnt2 ] && echo "pls move to cnt2" && exit 1
sudo rm -r ~/.ssh &> /dev/null
echo '' | ssh-keygen -t rsa -P '' &>/dev/null
cp ~/.ssh/id_rsa.pub ~/.ssh/authorized_keys

for n in $CLUSTER
do
  nc -w 1 -z $n 22 &>/dev/null
  if [ "$?" == "0" ];then
    sshpass -p 'bigred' ssh -q $n cat /etc/os-release|grep 'NAME="Alpine Linux"' &>/dev/null
    [ $? != 0 ] && echo "$n system is not alpine" && exit 1
    sshpass -p 'bigred' ssh $n 'sudo rm -r ~/.ssh/ ' &>/dev/null
    sshpass -p 'bigred' ssh $n 'mkdir -p ~/.ssh '
    sshpass -p 'bigred' scp -r ~/.ssh/ $n:~ 
    sshpass -p 'bigred' ssh $n 'chmod -R 700 .ssh/ '
    sshpass -p 'bigred' ssh $n 'rm ~/.ssh/known_hosts '
    echo "$n ssh key ok"
  fi
done

