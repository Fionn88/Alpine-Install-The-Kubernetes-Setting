#!/bin/bash

read -p "first student number:" $stufirst
read -p "first student number:" $stulast

[ $1 == " " ] && echo "please enter your number" && exit 1
 
for i in (1..50)
