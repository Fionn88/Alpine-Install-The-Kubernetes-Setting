#!/bin/bash
busybox httpd -p 8888 -h /www 
echo $! >>/tmp/my-app.pid

echo $(cat /tmp/my-app.pid)"
