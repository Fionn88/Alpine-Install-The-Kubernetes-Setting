#!/bin/bash
source ~/cnt/config
[ `hostname` != "${HN}" ] && echo "wrong hostname" && exit 1
[ `whoami` != "${UR}" ] && echo "wrong user" && exit 1
[ `pwd` != "${DR}" ] && echo "pls move to ${DR}" && exit 1
echo '' | ssh-keygen -t rsa -P '' &>/dev/null
cp ~/.ssh/id_rsa.pub ~/.ssh/authorized_keys

for n in ${CLUSTER}
do
  nc -w 1 -z $n 22 &>/dev/null
  if [ "$?" == "0" ];then
    sshpass -p 'bigred' ssh -q $n cat /etc/os-release|grep 'NAME="Alpine Linux"' &>/dev/null
    if [ "$?" = "0" ];then  
      sshpass -p 'bigred' ssh $n ls ~/.ssh/id_rsa &>/dev/null
      if [ $? != 0 ];then
        sshpass -p 'bigred' ssh $n 'sudo rm -r ~/.ssh/ &>/dev/null'
        sshpass -p 'bigred' ssh $n 'mkdir -p ~/.ssh'
        sshpass -p 'bigred' scp -r ~/.ssh/ $n:~
        sshpass -p 'bigred' ssh $n 'chmod -R 700 .ssh/'
        sshpass -p 'bigred' ssh $n 'rm ~/.ssh/known_hosts'
        sshpass -p 'bigred' ssh $n 'echo "PATH=.:$PATH" > ~/.ssh/environment' &>/dev/null
        echo "$n system prepare ok"
      else
        echo "$n .ssh created"  
      fi
    else
      echo "${n} is not alpine" 
    fi
  else
    echo "can not connect to ${n}"
  fi
done
