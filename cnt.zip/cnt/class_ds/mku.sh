#!/bin/bash
[ -z $1 ] && echo "pls enter class name" && exit 1
[ -z $2 ] && echo "pls enter first number of students" && exit 1
[ -z $3 ] && echo "pls enter last number of students" && exit 1
source config
export MAS_IP=${MAS_IP}
which envsubst &>/dev/null
[ $? != 0 ] && sudo apk add gettext &>/dev/null
which kubectl &>/dev/null
[ $? != 0 ] && curl -LO "https://storage.googleapis.com/kubernetes-release/release/$(curl -s https://storage.googleapis.com/kubernetes-release/release/stable.txt)/bin/linux/amd64/kubectl" &>/dev/null && chmod +x kubectl && sudo mv kubectl /usr/bin && echo "kubectl ok"
[ ! -f ".kube/config" ] && mkdir -p .kube && scp mas01:/etc/rancher/k3s/k3s.yaml .kube/config &>/dev/null

for n in $(seq $2 $3)
do
export stu=${1}${n}
if [ ! -d  /home/${stu} ];then
  sudo  adduser -s /bin/bash -h /home/${stu} -D ${stu}
  echo -e "${stu}\n${stu}\n" | sudo passwd ${stu} &> /dev/null
  echo "${stu} ready"  
  ssh mas01 ls ~/class/student/${stu}.key &> /dev/null
  if [ $? = 0 ];  then 
    mkdir ${stu}
    scp mas01:${DIR_CSR}${stu}.* ${stu}/ &>/dev/null
    sudo mv ${stu} /home/${stu}/ &>/dev/null
    sudo chmod 700 /home/${stu}/${stu}/${stu}.*
  else
    echo "${stu} key not exist"
  fi
  sudo mkdir -p /home/${stu}/.kube
  cat .kube/config | head -n 4 > ${stu}.config
  cat context.temp  | envsubst  >> ${stu}.config
  sudo mv ${stu}.config /home/${stu}/.kube/config
  sudo chown -R ${stu}:${stu} /home/${stu}
else
  echo "${stu} is exist"
fi
done
