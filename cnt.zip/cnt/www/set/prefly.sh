#!/bin/bash
apk update &> /dev/null
apk upgrade &> /dev/null
[ $? = 0 ] && echo "system upgrade ok"
for ap in nano bash curl tree sudo grep procps
do
which $ap &>/dev/null
[ "$?" != "0" ] && apk add ${ap} &> /dev/null
[ $? = 0 ] && echo "${ap} add ok"
done

cat /etc/sudoers | tail -n 5 | grep "%wheel ALL=(ALL) NOPASSWD:ALL" &>/dev/null
[ $? != 0 ] && echo '%wheel ALL=(ALL) NOPASSWD:ALL' >> /etc/sudoers && echo "sudo Nopasswd OK"

cat /etc/ssh/ssh_config | tail -n 5 | grep "StrictHostKeyChecking no" &>/dev/null
[ $? != 0 ] && echo 'StrictHostKeyChecking no' >> /etc/ssh/ssh_config

cat /etc/ssh/sshd_config | tail -n 5 | grep "PermitUserEnvironment yes" &>/dev/null
[ $? != 0 ] && echo 'PermitUserEnvironment yes' >> /etc/ssh/sshd_config


if [ ! -d  /home/bigred ];then
  adduser -s /bin/bash -h /home/bigred -D bigred
  addgroup bigred wheel
  echo -e "bigred\nbigred\n" | passwd bigred &> /dev/null
  echo "bigred ready"
else
echo "bigred exist"
fi
